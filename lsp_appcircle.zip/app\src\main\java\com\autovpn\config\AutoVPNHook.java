package com.autovpn.config;

import android.app.Activity;
import android.os.Bundle;

import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

/**
 * LSPosed 模块入口：根据 /data/adb/v2ray_autostart/config.json 中的 apps 列表决定 Hook 范围。
 * <p>
 * 若你有原版 AutoVPNHook.java，可直接覆盖本文件后重新编译。
 */
public class AutoVPNHook implements IXposedHookLoadPackage {

    /** 主路径（需 root/Magisk 侧保证对目标进程可读，否则可能失败） */
    private static final String[] CONFIG_PATHS = {
            "/data/adb/v2ray_autostart/config.json",
            "/sdcard/v2ray_autostart_config.json"
    };
    private static volatile Set<String> cachedApps;
    private static volatile long lastLoadMs;

    private static final long CACHE_TTL_MS = 30_000L;

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lpparam) throws Throwable {
        if (!isTargetApp(lpparam.packageName)) {
            return;
        }

        XposedBridge.log("AutoVPNHook: 已加载目标包 " + lpparam.packageName);

        XposedHelpers.findAndHookMethod(
                Activity.class,
                "onCreate",
                Bundle.class,
                new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam param) {
                        Activity a = (Activity) param.thisObject;
                        XposedBridge.log("AutoVPNHook: Activity.onCreate — " + a.getClass().getName());
                    }
                });
    }

    static boolean isTargetApp(String packageName) {
        Set<String> apps = getAppsFromConfig();
        return apps != null && apps.contains(packageName);
    }

    private static Set<String> getAppsFromConfig() {
        long now = System.currentTimeMillis();
        if (cachedApps != null && (now - lastLoadMs) < CACHE_TTL_MS) {
            return cachedApps;
        }
        synchronized (AutoVPNHook.class) {
            if (cachedApps != null && (now - lastLoadMs) < CACHE_TTL_MS) {
                return cachedApps;
            }
            cachedApps = loadAppsFromCandidates();
            lastLoadMs = System.currentTimeMillis();
            return cachedApps;
        }
    }

    private static Set<String> loadAppsFromCandidates() {
        for (String path : CONFIG_PATHS) {
            File f = new File(path);
            Set<String> apps = loadAppsFromFile(f);
            if (!apps.isEmpty()) {
                return apps;
            }
        }
        XposedBridge.log("AutoVPNHook: 所有配置路径均不可用，请检查权限或改用 /sdcard/v2ray_autostart_config.json");
        return Collections.emptySet();
    }

    private static Set<String> loadAppsFromFile(File file) {
        if (!file.isFile() || !file.canRead()) {
            XposedBridge.log("AutoVPNHook: 跳过（不可读或不存在）: " + file.getAbsolutePath());
            return Collections.emptySet();
        }
        try (FileInputStream fis = new FileInputStream(file);
             BufferedReader reader = new BufferedReader(
                     new InputStreamReader(fis, StandardCharsets.UTF_8))) {
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                sb.append(line);
            }
            JSONObject root = new JSONObject(new JSONTokener(sb.toString()));
            JSONArray apps = root.optJSONArray("apps");
            if (apps == null) {
                XposedBridge.log("AutoVPNHook: config.json 缺少 apps 数组");
                return Collections.emptySet();
            }
            HashSet<String> set = new HashSet<>();
            for (int i = 0; i < apps.length(); i++) {
                String pkg = apps.optString(i, null);
                if (pkg != null && !pkg.isEmpty()) {
                    set.add(pkg);
                }
            }
            XposedBridge.log("AutoVPNHook: 已载入 apps 数量=" + set.size());
            return set;
        } catch (Throwable t) {
            XposedBridge.log(t);
            return Collections.emptySet();
        }
    }
}
