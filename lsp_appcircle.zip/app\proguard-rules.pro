# LSPosed / Xposed module — keep entry class
-keep class com.autovpn.config.AutoVPNHook { *; }
