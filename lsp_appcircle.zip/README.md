# AppCircle构建配置

## 项目信息
这是一个Xposed/LSPosed模块项目，用于根据配置文件动态Hook指定应用。

## 构建配置
- **构建命令**: `./gradlew assembleDebug`
- **输出文件**: `app/build/outputs/apk/debug/app-debug.apk`
- **Android SDK**: 34
- **Java版本**: 17

## 依赖库
- `de.robv.android.xposed:api:82`
- `org.json:json:20210307`

## 注意事项
1. 这是一个Xposed模块，需要在已root的设备上运行
2. 需要LSPosed框架支持
3. 模块会读取 `/data/adb/v2ray_autostart/config.json` 配置文件

## 快速测试
构建成功后，下载APK安装到Android设备，在LSPosed中启用即可。