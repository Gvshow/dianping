#!/system/bin/sh
# 自动VPN模块服务脚本

CONFIG_PATH="/data/adb/v2ray_autostart/config.json"

# 初始化配置目录和文件
mkdir -p /data/adb/v2ray_autostart
if [ ! -f "$CONFIG_PATH" ]; then
    echo '{"apps":[]}' > "$CONFIG_PATH"
    chmod 600 "$CONFIG_PATH"
fi