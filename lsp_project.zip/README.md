# AutoVPN Xposed Module

这是一个Xposed/LSPosed模块，用于根据配置文件动态Hook指定应用。

## 功能
- 读取 `/data/adb/v2ray_autostart/config.json` 中的apps列表
- 动态Hook配置文件中指定的应用
- 支持缓存机制，提高性能

## 配置文件格式
```json
{
  "apps": ["com.example.app1", "com.example.app2"]
}
```

## 构建说明
使用在线构建服务（如AppCircle或CodeMagic）构建此项目。

## 使用方法
1. 安装构建的APK
2. 在LSPosed中启用此模块
3. 选择要Hook的应用范围
4. 创建配置文件 `/data/adb/v2ray_autostart/config.json` 或 `/sdcard/v2ray_autostart_config.json`
5. 重启目标应用

## 依赖
- Xposed Framework 93+
- Root权限（用于读取配置文件）