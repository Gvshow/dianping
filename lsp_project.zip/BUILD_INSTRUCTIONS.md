# 在线构建配置

## 构建说明
这是一个Xposed/LSPosed模块项目，需要以下依赖：
- Android SDK 34
- Java 17
- Xposed API 82
- JSON库

## 构建命令
```bash
./gradlew assembleDebug
```

## 输出文件
构建完成后，APK文件位于：
- `app/build/outputs/apk/debug/app-debug.apk`

## 项目信息
- 包名: com.autovpn.config
- 目标SDK: 34
- 最低SDK: 24
- 版本: 1.0

## 在线构建服务配置建议
### AppCircle
1. 上传此文件夹
2. 选择Android构建
3. 使用默认配置
4. 构建命令: `./gradlew assembleDebug`

### CodeMagic
1. 上传此文件夹
2. 选择Android项目
3. 构建类型: Debug
4. 构建命令: `./gradlew assembleDebug`

## 注意事项
1. 这是一个Xposed模块，需要在已root的设备或LSPosed环境中运行
2. 模块需要读取 `/data/adb/v2ray_autostart/config.json` 配置文件
3. 确保构建服务支持Android SDK 34和Java 17