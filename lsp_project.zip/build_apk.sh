#!/bin/bash
echo "准备构建APK..."

# 检查Java
if ! command -v java &> /dev/null; then
    echo "错误: 未找到Java。请安装Java 17或更高版本。"
    echo "下载地址: https://www.oracle.com/java/technologies/downloads/"
    exit 1
fi

# 检查Android SDK
if [ -z "$ANDROID_HOME" ] && [ ! -d "$HOME/Android/Sdk" ] && [ ! -d "/usr/local/android-sdk" ]; then
    echo "警告: 未找到Android SDK。将尝试使用在线构建。"
fi

# 创建构建目录
BUILD_DIR="build_temp"
[ -d "$BUILD_DIR" ] && rm -rf "$BUILD_DIR"
mkdir -p "$BUILD_DIR"

echo "复制项目文件..."
cp -r app/src "$BUILD_DIR/"
cp app/build.gradle "$BUILD_DIR/"
cp app/proguard-rules.pro "$BUILD_DIR/"

echo "创建构建配置..."
cat > "$BUILD_DIR/build.gradle" << 'EOF'
plugins {
    id 'com.android.application'
}

android {
    namespace 'com.autovpn.config'
    compileSdk 34

    defaultConfig {
        applicationId "com.autovpn.config"
        minSdk 24
        targetSdk 34
        versionCode 1
        versionName "1.0"
    }

    buildTypes {
        release {
            minifyEnabled false
            proguardFiles getDefaultProguardFile('proguard-android-optimize.txt'), 'proguard-rules.pro'
        }
    }

    compileOptions {
        sourceCompatibility JavaVersion.VERSION_17
        targetCompatibility JavaVersion.VERSION_17
    }
}

dependencies {
    implementation 'de.robv.android.xposed:api:82'
    implementation 'org.json:json:20210307'
}
EOF

echo "创建AndroidManifest.xml..."
mkdir -p "$BUILD_DIR/src/main"
cat > "$BUILD_DIR/src/main/AndroidManifest.xml" << 'EOF'
<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android">

    <application
        android:allowBackup="true"
        android:label="AutoVPN Config"
        android:supportsRtl="true">

        <meta-data
            android:name="xposedmodule"
            android:value="true" />
        <meta-data
            android:name="xposeddescription"
            android:value="AutoVPN：读取 /data/adb/v2ray_autostart/config.json 中的 apps 列表（按需扩展 Hook）" />
        <meta-data
            android:name="xposedminversion"
            android:value="93" />
        <meta-data
            android:name="xposedscope"
            android:value="*" />
    </application>
</manifest>
EOF

echo "创建资源文件..."
mkdir -p "$BUILD_DIR/src/main/res/values"
cat > "$BUILD_DIR/src/main/res/values/strings.xml" << 'EOF'
<?xml version="1.0" encoding="utf-8"?>
<resources>
    <string name="app_name">AutoVPN Config</string>
</resources>
EOF

cat > "$BUILD_DIR/src/main/res/values/arrays.xml" << 'EOF'
<?xml version="1.0" encoding="utf-8"?>
<resources>
    <array name="xposed_scope">
        <item>*</item>
    </array>
</resources>
EOF

echo ""
echo "构建环境准备完成！"
echo ""
echo "由于缺少Android SDK，建议使用以下方法之一："
echo ""
echo "方法1: 安装Android Studio"
echo "  1. 下载并安装Android Studio"
echo "  2. 打开项目文件夹 lsp"
echo "  3. 点击 Build -> Build Bundle(s) / APK(s) -> Build APK(s)"
echo ""
echo "方法2: 使用在线构建服务"
echo "  1. 访问 https://appcircle.io/ 或 https://codemagic.io/"
echo "  2. 上传项目文件"
echo "  3. 选择Android构建"
echo ""
echo "方法3: 使用命令行构建（需要Android SDK）"
echo "  1. 安装Android SDK命令行工具"
echo "  2. 运行: ./gradlew assembleDebug"
echo ""
echo "当前项目结构已准备好，可以上传到构建服务。"
echo "构建输出将位于: $BUILD_DIR/build/outputs/apk/debug"
