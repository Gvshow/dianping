@echo off
echo 正在准备构建环境...
echo.

echo 1. 检查Java环境...
where java >nul 2>nul
if %errorlevel% neq 0 (
    echo 错误: 未找到Java。请安装Java 17或更高版本。
    echo 下载地址: https://www.oracle.com/java/technologies/downloads/
    pause
    exit /b 1
)

echo 2. 检查Android SDK...
if not exist "%ANDROID_HOME%" (
    if not exist "%LOCALAPPDATA%\Android\Sdk" (
        if not exist "%USERPROFILE%\AppData\Local\Android\Sdk" (
            echo 警告: 未找到Android SDK。将尝试使用在线构建。
        )
    )
)

echo 3. 创建临时构建脚本...
echo.

set BUILD_DIR=build_temp
if exist "%BUILD_DIR%" rmdir /s /q "%BUILD_DIR%"
mkdir "%BUILD_DIR%"

echo 正在复制项目文件...
xcopy "app\src" "%BUILD_DIR%\src" /E /I /Y
xcopy "app\build.gradle" "%BUILD_DIR%\build.gradle" /Y
xcopy "app\proguard-rules.pro" "%BUILD_DIR%\proguard-rules.pro" /Y

echo 创建简易构建配置...
(
echo plugins {
echo     id 'com.android.application'
echo }
echo 
echo android {
echo     namespace 'com.autovpn.config'
echo     compileSdk 34
echo 
echo     defaultConfig {
echo         applicationId "com.autovpn.config"
echo         minSdk 24
echo         targetSdk 34
echo         versionCode 1
echo         versionName "1.0"
echo     }
echo 
echo     buildTypes {
echo         release {
echo             minifyEnabled false
echo             proguardFiles getDefaultProguardFile('proguard-android-optimize.txt'), 'proguard-rules.pro'
echo         }
echo     }
echo 
echo     compileOptions {
echo         sourceCompatibility JavaVersion.VERSION_17
echo         targetCompatibility JavaVersion.VERSION_17
echo     }
echo }
echo 
echo dependencies {
echo     implementation 'de.robv.android.xposed:api:82'
echo     implementation 'org.json:json:20210307'
echo }
) > "%BUILD_DIR%\build.gradle"

echo 创建AndroidManifest.xml...
(
echo ^<?xml version="1.0" encoding="utf-8"?^>
echo ^<manifest xmlns:android="http://schemas.android.com/apk/res/android"^>
echo 
echo     ^<application
echo         android:allowBackup="true"
echo         android:label="AutoVPN Config"
echo         android:supportsRtl="true"^>
echo 
echo         ^<meta-data
echo             android:name="xposedmodule"
echo             android:value="true" /^>
echo         ^<meta-data
echo             android:name="xposeddescription"
echo             android:value="AutoVPN：读取 /data/adb/v2ray_autostart/config.json 中的 apps 列表（按需扩展 Hook）" /^>
echo         ^<meta-data
echo             android:name="xposedminversion"
echo             android:value="93" /^>
echo         ^<meta-data
echo             android:name="xposedscope"
echo             android:value="*" /^>
echo     ^</application^>
echo ^</manifest^>
) > "%BUILD_DIR%\src\main\AndroidManifest.xml"

echo 创建资源文件...
if not exist "%BUILD_DIR%\src\main\res\values" mkdir "%BUILD_DIR%\src\main\res\values"
(
echo ^<?xml version="1.0" encoding="utf-8"?^>
echo ^<resources^>
echo     ^<string name="app_name"^>AutoVPN Config^</string^>
echo ^</resources^>
) > "%BUILD_DIR%\src\main\res\values\strings.xml"

(
echo ^<?xml version="1.0" encoding="utf-8"?^>
echo ^<resources^>
echo     ^<array name="xposed_scope"^>
echo         ^<item^>*^</item^>
echo     ^</array^>
echo ^</resources^>
) > "%BUILD_DIR%\src\main\res\values\arrays.xml"

echo.
echo 构建环境准备完成！
echo.
echo 由于缺少Android SDK，建议使用以下方法之一：
echo.
echo 方法1: 安装Android Studio
echo   1. 下载并安装Android Studio
echo   2. 打开项目文件夹 lsp
echo   3. 点击 Build -> Build Bundle(s) / APK(s) -> Build APK(s)
echo.
echo 方法2: 使用在线构建服务
echo   1. 访问 https://appcircle.io/ 或 https://codemagic.io/
echo   2. 上传项目文件
echo   3. 选择Android构建
echo.
echo 方法3: 使用命令行构建（需要Android SDK）
echo   1. 安装Android SDK命令行工具
echo   2. 运行: gradlew assembleDebug
echo.
echo 当前项目结构已准备好，可以上传到构建服务。
echo 构建输出将位于: %BUILD_DIR%\build\outputs\apk\debug
pause
