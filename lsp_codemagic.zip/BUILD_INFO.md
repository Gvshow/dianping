# CodeMagic Android构建配置

## 项目信息
- **应用ID**: com.autovpn.config
- **构建类型**: Debug
- **Android SDK**: 34
- **Java版本**: 17

## 构建命令
```bash
chmod +x ./gradlew
./gradlew assembleDebug
```

## 输出文件
构建成功后，下载以下文件：
- `app/build/outputs/apk/debug/app-debug.apk`

## 依赖说明
项目使用以下依赖，CodeMagic会自动下载：
- Xposed API 82
- JSON库 20210307

## 注意事项
1. 这是一个Xposed/LSPosed模块
2. 需要在已root的Android设备上运行
3. 需要LSPosed框架支持